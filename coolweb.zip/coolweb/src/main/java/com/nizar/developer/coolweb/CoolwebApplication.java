package com.nizar.developer.coolweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoolwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoolwebApplication.class, args);
	}
}
